# CI-CD-Deployment-for-Springboot-WebApp
This is simple springboot web application for Testing Phase with Deployment
